# stanford-lagunita-cs1-compilers-grading-scripts
This repo contains the grading scripts for the online course. The reason they are here is because the server for which the grading scripts are normally obtained now returns HTTP 403 FORBIDDEN.

PA1 was gotten from the server before it started returning HTTP 403.

The rest were gotten from other users' repos.
Should they not be the correct grading script, you can try finding them in the same manner.
