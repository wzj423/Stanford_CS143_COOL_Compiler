
//**************************************************************
//
// Code generator SKELETON
//
// Read the comments carefully. Make sure to
//    initialize the base class tags in
//       `CgenClassTable::CgenClassTable'
//
//    Add the label for the dispatch tables to
//       `IntEntry::code_def'
//       `StringEntry::code_def'
//       `BoolConst::code_def'
//
//    Add code to emit everyting else that is needed
//       in `CgenClassTable::code'
//
//
// The files as provided will produce code to begin the code
// segments, declare globals, and emit constants.  You must
// fill in the rest.
//
//**************************************************************

#include "cgen.h"
#include "cgen_gc.h"

extern void emit_string_constant(ostream& str, char *s);
extern int cgen_debug;
#define dbgStream if(!cgen_debug) {} else cerr

//
// Three symbols from the semantic analyzer (semant.cc) are used.
// If e : No_type, then no code is generated for e.
// Special code is generated for new SELF_TYPE.
// The name "self" also generates code different from other references.
//
//////////////////////////////////////////////////////////////////////
//
// Symbols
//
// For convenience, a large number of symbols are predefined here.
// These symbols include the primitive type and method names, as well
// as fixed names used by the runtime system.
//
//////////////////////////////////////////////////////////////////////
Symbol 
       arg,
       arg2,
       Bool,
       concat,
       cool_abort,
       copy,
       Int,
       in_int,
       in_string,
       IO,
       length,
       Main,
       main_meth,
       No_class,
       No_type,
       Object,
       out_int,
       out_string,
       prim_slot,
       self,
       SELF_TYPE,
       Str,
       str_field,
       substr,
       type_name,
       val;
//
// Initializing the predefined symbols.
//
static void initialize_constants(void)
{
  arg         = idtable.add_string("arg");
  arg2        = idtable.add_string("arg2");
  Bool        = idtable.add_string("Bool");
  concat      = idtable.add_string("concat");
  cool_abort  = idtable.add_string("abort");
  copy        = idtable.add_string("copy");
  Int         = idtable.add_string("Int");
  in_int      = idtable.add_string("in_int");
  in_string   = idtable.add_string("in_string");
  IO          = idtable.add_string("IO");
  length      = idtable.add_string("length");
  Main        = idtable.add_string("Main");
  main_meth   = idtable.add_string("main");
//   _no_class is a symbol that can't be the name of any 
//   user-defined class.
  No_class    = idtable.add_string("_no_class");
  No_type     = idtable.add_string("_no_type");
  Object      = idtable.add_string("Object");
  out_int     = idtable.add_string("out_int");
  out_string  = idtable.add_string("out_string");
  prim_slot   = idtable.add_string("_prim_slot");
  self        = idtable.add_string("self");
  SELF_TYPE   = idtable.add_string("SELF_TYPE");
  Str         = idtable.add_string("String");
  str_field   = idtable.add_string("_str_field");
  substr      = idtable.add_string("substr");
  type_name   = idtable.add_string("type_name");
  val         = idtable.add_string("_val");
}

static char *gc_init_names[] =
  { "_NoGC_Init", "_GenGC_Init", "_ScnGC_Init" };
static char *gc_collect_names[] =
  { "_NoGC_Collect", "_GenGC_Collect", "_ScnGC_Collect" };

inline bool is_basic_classes(Symbol name)
{
  return name == Object || name == IO || name == Str || name == Int || name == Bool;
}

//  BoolConst is a class that implements code generation for operations
//  on the two booleans, which are given global names here.
BoolConst falsebool(FALSE);
BoolConst truebool(TRUE);

//*********************************************************
//
// Define method for code generation
//
// This is the method called by the compiler driver
// `cgtest.cc'. cgen takes an `ostream' to which the assembly will be
// emmitted, and it passes this and the class list of the
// code generator tree to the constructor for `CgenClassTable'.
// That constructor performs all of the work of the code
// generator.
//
//*********************************************************

CgenClassTable *codegen_classtable;
auto& ct=codegen_classtable;

int label_count=0;
inline int alloc_label() {
  return label_count ++;
}

void program_class::cgen(ostream &os) 
{
  // spim wants comments to start with '#'
  os << "# start of generated code\n";
  dbgStream<<OBJECTPROTOBJ<<endl;
  initialize_constants();
  codegen_classtable = new CgenClassTable(classes,os,codegen_classtable);
  delete codegen_classtable;
  os << "\n# end of generated code\n";
}


//////////////////////////////////////////////////////////////////////////////
//
//  emit_* procedures
//
//  emit_X  writes code for operation "X" to the output stream.
//  There is an emit_X for each opcode X, as well as emit_ functions
//  for generating names according to the naming conventions (see emit.h)
//  and calls to support functions defined in the trap handler.
//
//  Register names and addresses are passed as strings.  See `emit.h'
//  for symbolic names you can use to refer to the strings.
//
//////////////////////////////////////////////////////////////////////////////

static void emit_load(char *dest_reg, int offset, char *source_reg, ostream& s)
{
  s << LW << dest_reg << " " << offset * WORD_SIZE << "(" << source_reg << ")" 
    << endl;
}

static void emit_store(char *source_reg, int offset, char *dest_reg, ostream& s)
{
  s << SW << source_reg << " " << offset * WORD_SIZE << "(" << dest_reg << ")"
      << endl;
}

static void emit_load_imm(char *dest_reg, int val, ostream& s)
{ s << LI << dest_reg << " " << val << endl; }

static void emit_load_address(char *dest_reg, char *address, ostream& s)
{ s << LA << dest_reg << " " << address << endl; }

static void emit_partial_load_address(char *dest_reg, ostream& s)
{ s << LA << dest_reg << " "; }

static void emit_load_bool(char *dest, const BoolConst& b, ostream& s)
{
  emit_partial_load_address(dest,s);
  b.code_ref(s);
  s << endl;
}

static void emit_load_string(char *dest, StringEntry *str, ostream& s)
{
  emit_partial_load_address(dest,s);
  str->code_ref(s);
  s << endl;
}

static void emit_load_int(char *dest, IntEntry *i, ostream& s)
{
  emit_partial_load_address(dest,s);
  i->code_ref(s);
  s << endl;
}

static void emit_move(char *dest_reg, char *source_reg, ostream& s)
{ s << MOVE << dest_reg << " " << source_reg << endl; }

static void emit_neg(char *dest, char *src1, ostream& s)
{ s << NEG << dest << " " << src1 << endl; }

static void emit_add(char *dest, char *src1, char *src2, ostream& s)
{ s << ADD << dest << " " << src1 << " " << src2 << endl; }

static void emit_addu(char *dest, char *src1, char *src2, ostream& s)
{ s << ADDU << dest << " " << src1 << " " << src2 << endl; }

static void emit_addiu(char *dest, char *src1, int imm, ostream& s)
{ s << ADDIU << dest << " " << src1 << " " << imm << endl; }

static void emit_div(char *dest, char *src1, char *src2, ostream& s)
{ s << DIV << dest << " " << src1 << " " << src2 << endl; }

static void emit_mul(char *dest, char *src1, char *src2, ostream& s)
{ s << MUL << dest << " " << src1 << " " << src2 << endl; }

static void emit_sub(char *dest, char *src1, char *src2, ostream& s)
{ s << SUB << dest << " " << src1 << " " << src2 << endl; }

static void emit_sll(char *dest, char *src1, int num, ostream& s)
{ s << SLL << dest << " " << src1 << " " << num << endl; }

static void emit_jalr(char *dest, ostream& s)
{ s << JALR << "\t" << dest << endl; }

static void emit_jal(char *address,ostream &s)
{ s << JAL << address << endl; }

static void emit_return(ostream& s)
{ s << RET << endl; }

static void emit_gc_assign(ostream& s)
{ s << JAL << "_GenGC_Assign" << endl; }

static void emit_disptable_ref(Symbol sym, ostream& s)
{  s << sym << DISPTAB_SUFFIX; }

static void emit_init_ref(Symbol sym, ostream& s)
{ s << sym << CLASSINIT_SUFFIX; }

static void emit_label_ref(int l, ostream &s)
{ s << "label" << l; }

static void emit_protobj_ref(Symbol sym, ostream& s)
{ s << sym << PROTOBJ_SUFFIX; }

static void emit_method_ref(Symbol classname, Symbol methodname, ostream& s)
{ s << classname << METHOD_SEP << methodname; }

static void emit_label_def(int l, ostream &s)
{
  emit_label_ref(l,s);
  s << ":" << endl;
}

static void emit_beqz(char *source, int label, ostream &s)
{
  s << BEQZ << source << " ";
  emit_label_ref(label,s);
  s << endl;
}

static void emit_beq(char *src1, char *src2, int label, ostream &s)
{
  s << BEQ << src1 << " " << src2 << " ";
  emit_label_ref(label,s);
  s << endl;
}

static void emit_bne(char *src1, char *src2, int label, ostream &s)
{
  s << BNE << src1 << " " << src2 << " ";
  emit_label_ref(label,s);
  s << endl;
}

static void emit_bleq(char *src1, char *src2, int label, ostream &s)
{
  s << BLEQ << src1 << " " << src2 << " ";
  emit_label_ref(label,s);
  s << endl;
}

static void emit_blt(char *src1, char *src2, int label, ostream &s)
{
  s << BLT << src1 << " " << src2 << " ";
  emit_label_ref(label,s);
  s << endl;
}

static void emit_blti(char *src1, int imm, int label, ostream &s)
{
  s << BLT << src1 << " " << imm << " ";
  emit_label_ref(label,s);
  s << endl;
}

static void emit_bgti(char *src1, int imm, int label, ostream &s)
{
  s << BGT << src1 << " " << imm << " ";
  emit_label_ref(label,s);
  s << endl;
}

static void emit_branch(int l, ostream& s)
{
  s << BRANCH;
  emit_label_ref(l,s);
  s << endl;
}

//
// Push a register on the stack. The stack grows towards smaller addresses.
//
static void emit_push(char *reg, ostream& str)
{
  emit_store(reg,0,SP,str);
  emit_addiu(SP,SP,-4,str);
}

//
// Fetch the integer value in an Int object.
// Emits code to fetch the integer value of the Integer object pointed
// to by register source into the register dest
//
static void emit_fetch_int(char *dest, char *source, ostream& s)
{ emit_load(dest, DEFAULT_OBJFIELDS, source, s); }

//
// Emits code to store the integer value contained in register source
// into the Integer object pointed to by dest.
//
static void emit_store_int(char *source, char *dest, ostream& s)
{ emit_store(source, DEFAULT_OBJFIELDS, dest, s); }


static void emit_test_collector(ostream &s)
{
  emit_push(ACC, s);
  emit_move(ACC, SP, s); // stack end
  emit_move(A1, ZERO, s); // allocate nothing
  s << JAL << gc_collect_names[cgen_Memmgr] << endl;
  emit_addiu(SP,SP,4,s);
  emit_load(ACC,0,SP,s);
}

static void emit_gc_check(char *source, ostream &s)
{
  if (source != (char*)A1) emit_move(A1, source, s);
  s << JAL << "_gc_check" << endl;
}

void push_local_var_on_stack(Symbol name,char * source,ostream&s) {
  emit_push(source,s);
  env.push_stack(name);
}
void pop_local_var_on_stack(char * dest,ostream& s) {
  emit_addiu(SP,SP,4,s);
  emit_load(dest,0,SP,s);
  env.pop_stack();
}
void pop_discard_local_var_on_stack(ostream&s) {
  emit_addiu(SP,SP,4,s);
  env.pop_stack();
}
/**
 * Student-defined emit functions
 * 
*/

/**
 * End of student-defined emit functions 
*/

///////////////////////////////////////////////////////////////////////////////
//
// coding strings, ints, and booleans
//
// Cool has three kinds of constants: strings, ints, and booleans.
// This section defines code generation for each type.
//
// All string constants are listed in the global "stringtable" and have
// type StringEntry.  StringEntry methods are defined both for String
// constant definitions and references.
//
// All integer constants are listed in the global "inttable" and have
// type IntEntry.  IntEntry methods are defined for Int
// constant definitions and references.
//
// Since there are only two Bool values, there is no need for a table.
// The two booleans are represented by instances of the class BoolConst,
// which defines the definition and reference methods for Bools.
//
///////////////////////////////////////////////////////////////////////////////

//
// Strings
//
void StringEntry::code_ref(ostream& s)
{
  s << STRCONST_PREFIX << index;
}

//
// Emit code for a constant String.
// You should fill in the code naming the dispatch table.
//

void StringEntry::code_def(ostream& s, int stringclasstag)
{
  IntEntryP lensym = inttable.add_int(len);

  // Add -1 eye catcher
  s << WORD << "-1" << endl;

  code_ref(s);  s  << LABEL                                             // label
      << WORD << stringclasstag << endl                                 // tag
      << WORD << (DEFAULT_OBJFIELDS + STRING_SLOTS + (len+4)/4) << endl // size
      << WORD;


 /***** Add dispatch information for class String ******/
      emit_disptable_ref(Str,s);
      s << endl;                                              // dispatch table
      s << WORD;  lensym->code_ref(s);  s << endl;            // string length
  emit_string_constant(s,str);                                // ascii string
  s << ALIGN;                                                 // align to word
}

//
// StrTable::code_string
// Generate a string object definition for every string constant in the 
// stringtable.
//
void StrTable::code_string_table(ostream& s, int stringclasstag)
{  
  for (List<StringEntry> *l = tbl; l; l = l->tl())
    l->hd()->code_def(s,stringclasstag);
}

//
// Ints
//
void IntEntry::code_ref(ostream &s)
{
  s << INTCONST_PREFIX << index;
}

//
// Emit code for a constant Integer.
// You should fill in the code naming the dispatch table.
//

void IntEntry::code_def(ostream &s, int intclasstag)
{
  // Add -1 eye catcher
  s << WORD << "-1" << endl;

  code_ref(s);  s << LABEL                                // label
      << WORD << intclasstag << endl                      // class tag
      << WORD << (DEFAULT_OBJFIELDS + INT_SLOTS) << endl  // object size
      << WORD; 

 /***** Add dispatch information for class Int ******/
      emit_disptable_ref(Int,s);
      s << endl;                                          // dispatch table
      s << WORD << str << endl;                           // integer value
}


//
// IntTable::code_string_table
// Generate an Int object definition for every Int constant in the
// inttable.
//
void IntTable::code_string_table(ostream &s, int intclasstag)
{
  for (List<IntEntry> *l = tbl; l; l = l->tl())
    l->hd()->code_def(s,intclasstag);
}


//
// Bools
//
BoolConst::BoolConst(int i) : val(i) { assert(i == 0 || i == 1); }

void BoolConst::code_ref(ostream& s) const
{
  s << BOOLCONST_PREFIX << val;
}
  
//
// Emit code for a constant Bool.
// You should fill in the code naming the dispatch table.
//

void BoolConst::code_def(ostream& s, int boolclasstag)
{
  // Add -1 eye catcher
  s << WORD << "-1" << endl;

  code_ref(s);  s << LABEL                                  // label
      << WORD << boolclasstag << endl                       // class tag
      << WORD << (DEFAULT_OBJFIELDS + BOOL_SLOTS) << endl   // object size
      << WORD;

 /***** Add dispatch information for class Bool ******/
      emit_disptable_ref(Bool,s);
      s << endl;                                            // dispatch table
      s << WORD << val << endl;                             // value (0 or 1)
}

//////////////////////////////////////////////////////////////////////////////
//
//  CgenClassTable methods
//
//////////////////////////////////////////////////////////////////////////////

//***************************************************
//
//  Emit code to start the .data segment and to
//  declare the global names.
//
//***************************************************

void CgenClassTable::code_global_data()
{
  Symbol main    = idtable.lookup_string(MAINNAME);
  Symbol string  = idtable.lookup_string(STRINGNAME);
  Symbol integer = idtable.lookup_string(INTNAME);
  Symbol boolc   = idtable.lookup_string(BOOLNAME);

  str << "\t.data\n" << ALIGN;
  //
  // The following global names must be defined first.
  //
  str << GLOBAL << CLASSNAMETAB << endl;
  str << GLOBAL; emit_protobj_ref(main,str);    str << endl;
  str << GLOBAL; emit_protobj_ref(integer,str); str << endl;
  str << GLOBAL; emit_protobj_ref(string,str);  str << endl;
  str << GLOBAL; falsebool.code_ref(str);  str << endl;
  str << GLOBAL; truebool.code_ref(str);   str << endl;
  str << GLOBAL << INTTAG << endl;
  str << GLOBAL << BOOLTAG << endl;
  str << GLOBAL << STRINGTAG << endl;

  //
  // We also need to know the tag of the Int, String, and Bool classes
  // during code generation.
  //
  str << INTTAG << LABEL
      << WORD << intclasstag << endl;
  str << BOOLTAG << LABEL 
      << WORD << boolclasstag << endl;
  str << STRINGTAG << LABEL 
      << WORD << stringclasstag << endl;    
}


//***************************************************
//
//  Emit code to start the .text segment and to
//  declare the global names.
//
//***************************************************

void CgenClassTable::code_global_text()
{
  str << GLOBAL << HEAP_START << endl
      << HEAP_START << LABEL 
      << WORD << 0 << endl
      << "\t.text" << endl
      << GLOBAL;
  emit_init_ref(idtable.add_string("Main"), str);
  str << endl << GLOBAL;
  emit_init_ref(idtable.add_string("Int"),str);
  str << endl << GLOBAL;
  emit_init_ref(idtable.add_string("String"),str);
  str << endl << GLOBAL;
  emit_init_ref(idtable.add_string("Bool"),str);
  str << endl << GLOBAL;
  emit_method_ref(idtable.add_string("Main"), idtable.add_string("main"), str);
  str << endl;
}

void CgenClassTable::code_bools(int boolclasstag)
{
  falsebool.code_def(str,boolclasstag);
  truebool.code_def(str,boolclasstag);
}

void CgenClassTable::code_select_gc()
{
  //
  // Generate GC choice constants (pointers to GC functions)
  //
  str << GLOBAL << "_MemMgr_INITIALIZER" << endl;
  str << "_MemMgr_INITIALIZER:" << endl;
  str << WORD << gc_init_names[cgen_Memmgr] << endl;
  str << GLOBAL << "_MemMgr_COLLECTOR" << endl;
  str << "_MemMgr_COLLECTOR:" << endl;
  str << WORD << gc_collect_names[cgen_Memmgr] << endl;
  str << GLOBAL << "_MemMgr_TEST" << endl;
  str << "_MemMgr_TEST:" << endl;
  str << WORD << (cgen_Memmgr_Test == GC_TEST) << endl;
}


//********************************************************
//
// Emit code to reserve space for and initialize all of
// the constants.  Class names should have been added to
// the string table (in the supplied code, is is done
// during the construction of the inheritance graph), and
// code for emitting string constants as a side effect adds
// the string's length to the integer table.  The constants
// are emmitted by running through the stringtable and inttable
// and producing code for each entry.
//
//********************************************************

void CgenClassTable::code_constants()
{
  //
  // Add constants that are required by the code generator.
  //
  stringtable.add_string("");
  inttable.add_string("0");

  stringtable.code_string_table(str,stringclasstag);
  inttable.code_string_table(str,intclasstag);
  code_bools(boolclasstag);
}


CgenClassTable::CgenClassTable(Classes classes, ostream& s,CgenClassTableP& reflect_ptr) : nds(NULL) , str(s)
{
  reflect_ptr=this;
   enterscope();
   if (cgen_debug) cout << "Building CgenClassTable" << endl;
   install_basic_classes();
   install_classes(classes);
   build_inheritance_tree();

   code();
   exitscope();
}

void CgenClassTable::install_basic_classes()
{

// The tree package uses these globals to annotate the classes built below.
  //curr_lineno  = 0;
  Symbol filename = stringtable.add_string("<basic class>");

//
// A few special class names are installed in the lookup table but not
// the class list.  Thus, these classes exist, but are not part of the
// inheritance hierarchy.
// No_class serves as the parent of Object and the other special classes.
// SELF_TYPE is the self class; it cannot be redefined or inherited.
// prim_slot is a class known to the code generator.
//
  addid(No_class,
	new CgenNode(class_(No_class,No_class,nil_Features(),filename),
			    Basic,this));
  addid(SELF_TYPE,
	new CgenNode(class_(SELF_TYPE,No_class,nil_Features(),filename),
			    Basic,this));
  addid(prim_slot,
	new CgenNode(class_(prim_slot,No_class,nil_Features(),filename),
			    Basic,this));

// 
// The Object class has no parent class. Its methods are
//        cool_abort() : Object    aborts the program
//        type_name() : Str        returns a string representation of class name
//        copy() : SELF_TYPE       returns a copy of the object
//
// There is no need for method bodies in the basic classes---these
// are already built in to the runtime system.
//
  CgenNodeP cnp_object,cnp_str,cnp_int,cnp_bool,cnp_io;
  install_class(
   cnp_object=new CgenNode(
    class_(Object, 
	   No_class,
	   append_Features(
           append_Features(
           single_Features(method(cool_abort, nil_Formals(), Object, no_expr())),
           single_Features(method(type_name, nil_Formals(), Str, no_expr()))),
           single_Features(method(copy, nil_Formals(), SELF_TYPE, no_expr()))),
	   filename),
    Basic,this));

// 
// The IO class inherits from Object. Its methods are
//        out_string(Str) : SELF_TYPE          writes a string to the output
//        out_int(Int) : SELF_TYPE               "    an int    "  "     "
//        in_string() : Str                    reads a string from the input
//        in_int() : Int                         "   an int     "  "     "
//
   install_class(
    cnp_io=new CgenNode(
     class_(IO, 
            Object,
            append_Features(
            append_Features(
            append_Features(
            single_Features(method(out_string, single_Formals(formal(arg, Str)),
                        SELF_TYPE, no_expr())),
            single_Features(method(out_int, single_Formals(formal(arg, Int)),
                        SELF_TYPE, no_expr()))),
            single_Features(method(in_string, nil_Formals(), Str, no_expr()))),
            single_Features(method(in_int, nil_Formals(), Int, no_expr()))),
	   filename),	    
    Basic,this));

//
// The Int class has no methods and only a single attribute, the
// "val" for the integer. 
//
   install_class(
    cnp_int=new CgenNode(
     class_(Int, 
	    Object,
            single_Features(attr(val, prim_slot, no_expr())),
	    filename),
     Basic,this));

//
// Bool also has only the "val" slot.
//
    install_class(
     cnp_bool=new CgenNode(
      class_(Bool, Object, single_Features(attr(val, prim_slot, no_expr())),filename),
      Basic,this));

//
// The class Str has a number of slots and operations:
//       val                                  ???
//       str_field                            the string itself
//       length() : Int                       length of the string
//       concat(arg: Str) : Str               string concatenation
//       substr(arg: Int, arg2: Int): Str     substring
//       
   install_class(
    cnp_str=new CgenNode(
      class_(Str, 
	     Object,
             append_Features(
             append_Features(
             append_Features(
             append_Features(
             single_Features(attr(val, Int, no_expr())),
            single_Features(attr(str_field, prim_slot, no_expr()))),
            single_Features(method(length, nil_Formals(), Int, no_expr()))),
            single_Features(method(concat, 
				   single_Formals(formal(arg, Str)),
				   Str, 
				   no_expr()))),
	    single_Features(method(substr, 
				   append_Formals(single_Formals(formal(arg, Int)), 
						  single_Formals(formal(arg2, Int))),
				   Str, 
				   no_expr()))),
	     filename),
        Basic,this));
}

// CgenClassTable::install_class
// CgenClassTable::install_classes
//
// install_classes enters a list of classes in the symbol table.
//
void CgenClassTable::install_class(CgenNodeP nd)
{
  Symbol name = nd->get_name();

  if (probe(name))
    {
      return;
    }

  // The class name is legal, so add it to the list of classes
  // and the symbol table.
  nds = new List<CgenNode>(nd,nds);
  addid(name,nd);

  // maintain the infos of student-added data-structures
  class_name_map[name]=nd;
  classes_list.push_back(nd);
}

void CgenClassTable::install_classes(Classes cs)
{
  for(int i = cs->first(); cs->more(i); i = cs->next(i))
    install_class(new CgenNode(cs->nth(i),NotBasic,this));

  install_class_tags();
}

void CgenClassTable::install_class_tags() {
  int tag=0;
  for(auto cp:classes_list) {
    cp->set_tag(tag++);//tags must start from zero!

    dbgStream<<class_name_map[cp->get_name()]->get_name()<<cp->get_tag()<<endl;
  }
  stringclasstag=class_name_map[Str]->get_tag();
  intclasstag=class_name_map[Int]->get_tag();
  boolclasstag=class_name_map[Bool]->get_tag();

  dbgStream<<stringclasstag<<intclasstag<<boolclasstag<<endl;
}
//
// CgenClassTable::build_inheritance_tree
//
void CgenClassTable::build_inheritance_tree()
{
  for(List<CgenNode> *l = nds; l; l = l->tl())
      set_relations(l->hd());
  
  build_full_methods_attrs();
}

/**
 * CgenClassTable::build_full_methods_attrs
 * 
 * Find every class' (represented by a CGenNodeP pointer) full features (with inheritance taking into consideration)
 * Non-recursive approaches
*/
void CgenClassTable::build_full_methods_attrs() {
  std::stack<CgenNodeP> S;
  S.push(class_name_map[Object]);
  while(!S.empty()) {
    CgenNodeP now=S.top();
    S.pop();
    now->set_full_features(class_name_map[now->get_parent()]);
    
    if(cgen_debug) {
      cout<<("Full table of class ")<<now->get_name()<<endl;
      cout<<"Attrs:"<<endl;
      for(auto x:now->get_full_attrs()) {
        cout<<'\t'<<x.second->name<<endl;
      }      
      cout<<"Methods:"<<endl;
      for(auto x:now->get_full_methods()) {
        cout<<'\t'<<x.second->name<<endl;
      }      
    }


    //go through now's childrens and push them onto the stack
    auto children=now->get_children();
    for (auto *l = children; l; l = l->tl()) {
      S.push(l->hd());
    }
  }
}

//
// CgenClassTable::set_relations
//
// Takes a CgenNode and locates its, and its parent's, inheritance nodes
// via the class table.  Parent and child pointers are added as appropriate.
//
void CgenClassTable::set_relations(CgenNodeP nd)
{
  CgenNode *parent_node = probe(nd->get_parent());
  nd->set_parentnd(parent_node);
  parent_node->add_child(nd);
}

void CgenNode::add_child(CgenNodeP n)
{
  children = new List<CgenNode>(n,children);
}

void CgenNode::set_parentnd(CgenNodeP p)
{
  assert(parentnd == NULL);
  assert(p != NULL);
  parentnd = p;
}

void CgenNode::set_full_features(CgenNodeP parent)    //(std::vector<attr_class *> &ancestor_attrs, std::vector<method_class *> &ancestor_methods)
{
  //std::vector<attr_class *> ancestor_attrs;
  //std::vector<method_class *> ancestor_methods;
  if(parent==nullptr || parent->get_name() == No_class) {
    //do_nothing
  } else {
    this->full_attrs = parent->get_full_attrs();
    this->full_methods = parent->get_full_methods();    
  }

  for (int i = features->first(); features->more(i); i = features->next(i))
  {
    attr_class *at = dynamic_cast<attr_class *>(features->nth(i));
    method_class *md = dynamic_cast<method_class *>(features->nth(i));
    if (at)
    {
      full_attrs.push_back(std::make_pair(this,at));
    }
    else if (md)
    {
      bool is_polymor=false;
      for(auto &x:full_methods) {
        if(x.second->name==md->name) {
          x=std::make_pair(this,md);
          is_polymor=true;
          break;
        }
      }
      if(!is_polymor)
        full_methods.push_back(std::make_pair(this,md));
    }
  }
}

/** Construct class_nameTab as a sequence of addresses(labels actually) str_constX objects
 *  since class names in the form of Str object is needed to refer to that class.
 *  Since this table is in the order of CgenClassTable::classes_list, the table can also be referred by
 *  class_tags. (REMEMBER TO CONVERT BYTES TO WORDS!)
*/
void CgenClassTable::code_class_name_table() {
  str<<CLASSNAMETAB<<LABEL;

  for( auto x : classes_list) {
    str<<WORD;
    stringtable.lookup_string(x->get_name()->get_string())->code_ref(str);
    str<<endl;
  }
}

void CgenClassTable::code_class_parent_name_table() {
  str<<CLASSPARENTNAMETAB<<LABEL;
  for(auto x:classes_list) {
    if(x->get_name()==Object) {
      str<<WORD<<NO_CLASS_TAG<<endl;    
    } else {
      str<<WORD<<class_name_map[x->get_parent()]->get_tag()<<endl;
    }

  }
}

/** Construct a table for all X_init and X_protObj.
 * 
*/
void CgenClassTable::code_class_obj_table() {
  str<<CLASSOBJTAB<<LABEL;

  for( auto x : classes_list) {
    str<<WORD<<x->get_name()->get_string()<<PROTOBJ_SUFFIX<<endl;
    str<<WORD<<x->get_name()->get_string()<<CLASSINIT_SUFFIX<<endl;
  }  
}

void CgenClassTable::code_dispatch_tables() {
  for(auto c:classes_list) {
    str<<c->get_name()->get_string()<<DISPTAB_SUFFIX<<LABEL;
    for( auto m:c->get_full_methods()) {
      str<<WORD<<m.first->get_name()<<'.'<<m.second->name<<endl;
    }
  }
}

void CgenClassTable::code_obj_prototypes() {
  for(auto c:classes_list) {
    str<<WORD<<-1<<endl;
    str<<c->get_name()<<PROTOBJ_SUFFIX<<LABEL;
    str<<WORD<<c->get_tag()<<endl;
    str<<WORD<<DEFAULT_OBJFIELDS+c->get_full_attrs().size()<<endl;
    str<<WORD<<c->get_name()<<DISPTAB_SUFFIX<<endl;

    for(auto attr:c->get_full_attrs()) {
      Symbol type=attr.second->type_decl;
      if(type==Bool) {
        str<<WORD;
        falsebool.code_ref(str);
        str<<endl;
      } else if(type==Int) {
        str<<WORD;
        inttable.lookup(0)->code_ref(str);
        str<<endl;        
      } else if(type==Str) {
        str<<WORD;
        stringtable.lookup_string("")->code_ref(str);
        str<<endl;
      } else {
        str<<WORD;
        str<<0;// Output a null(void) address as default value for any other objects.
        str<<endl;
      }
    }
  }
}

/** Emit the init procedure for each classes
 * 
 * (It is until here that we face the problem of emitting assemply codes directly.)
*/
void CgenClassTable::code_initializers() {
  for(auto c:classes_list) {
    str << c->get_name() << CLASSINIT_SUFFIX << LABEL;

    ///! Create a brand-new stack frame.
    emit_addiu(SP, SP, -12, str);
    emit_store(FP, 3, SP, str);//Note that only emit_addiu uses bytes NUMBER, others using words NUMBER
    emit_store(SELF, 2, SP, str);
    emit_store(RA, 1, SP, str);
    emit_addiu(FP, SP, 4, str);// set up the frame pointer

    //#define SELF "$s0"		// Ptr to self (callee saves) (emit.h)
    //save the self (now in a0)
    emit_move(SELF, ACC, str);

    //init parent
    if(c->get_name()!=Object) {
      str << JAL << c->get_parentnd()->get_name()<<CLASSINIT_SUFFIX << endl;
    }
    
    //Environment env;
    env.clear();
    env.set_cur_class(c);

    //Init every attribute our current class extends
    //since attributes inherited from parent should be
    //initialized by PARENTCLASS_init procedure.
    for(int i=0;i<env.get_cur_attrs().size();++i) {
      if(env.get_cur_attrs()[i].first==c) {// belongs to current class
        auto attr=env.get_cur_attrs()[i].second;

        //first init attr with default values.
        if (attr->type_decl == Str)
        {
          emit_load_string(ACC, stringtable.lookup_string(""), str);
          emit_store(ACC,DEFAULT_OBJFIELDS+i,SELF,str);
        }
        else if (attr->type_decl == Int)
        {
          emit_load_int(ACC, inttable.lookup_string("0"), str);
          emit_store(ACC,DEFAULT_OBJFIELDS+i,SELF,str);
        }
        else if (attr->type_decl == Bool)
        {
          emit_load_bool(ACC, falsebool, str);
          emit_store(ACC,DEFAULT_OBJFIELDS+i,SELF,str);
        } else {
          //str << LA << ACC << " " << attr->type_decl<<PROTOBJ_SUFFIX << endl; 
          //emit_jal("Object.copy",str);
          //str << JAL << attr->type_decl<<CLASSINIT_SUFFIX << endl;
        }


        //no need to initialize attributes without initial value.
        if( !attr->init->is_void()) {
          attr->init->code(str);
          //initialize the value of initial expression, with results stored in ACC(a0)
          emit_store(ACC,DEFAULT_OBJFIELDS+i,SELF,str);
          //store the return value

          /** README-TODO
           * for now(2021-10-18),since the only expression classes has code() implemented are builtin-classes
           * (Int Bool String), initializers can only deal with literal builtin values.
           * 
           * The framework needs furthur checking.
          */
        }
      }
    }

    emit_move(ACC, SELF, str);
    
    //! Delete and clean-up the stack frame
    emit_load(FP,3,SP,str);
    emit_load(SELF,2,SP,str);
    emit_load(RA,1,SP,str);
    emit_addiu(SP,SP,12,str);

    //return
    emit_return(str);
  }
}

/** go though every classes, generating assembly codes for their methods.
 *  (except the built-in classes and methods in trap.handler) 
*/
void CgenClassTable::code_methods() {
  for(auto c:classes_list) {
    if(!is_basic_classes(c->get_name())) {
      env.clear();
      env.set_cur_class(c);
      for(auto method : c->get_full_methods()) {
        if(method.first==c) {
          dbgStream<<"coding "<<method.first->get_name()<<"."<<method.second->name<<endl;
          method.second-> code(str);
        }
      }
    }
  }
}

void CgenClassTable::code()
{
  if (cgen_debug) cout << "coding global data" << endl;
  code_global_data();

  if (cgen_debug) cout << "choosing gc" << endl;
  code_select_gc();

  if (cgen_debug) cout << "coding constants" << endl;
  code_constants();

//                 Add your code to emit
//                   - prototype objects
//                   - class_nameTab
//                   - dispatch tables
//

// code the class_nameTab
  code_class_name_table();
  code_class_parent_name_table();//EMPTY for now, will be filled when needed.
  code_class_obj_table();
  code_dispatch_tables();
  code_obj_prototypes();


  if (cgen_debug) cout << "coding global text" << endl;
  code_global_text();

//                 Add your code to emit
//                   - object initializer
//                   - the class methods
//                   - etc...
  code_initializers();
  code_methods();
}


CgenNodeP CgenClassTable::root()
{
   return probe(Object);
}


///////////////////////////////////////////////////////////////////////
//
// CgenNode methods
//
///////////////////////////////////////////////////////////////////////

CgenNode::CgenNode(Class_ nd, Basicness bstatus, CgenClassTableP ct) :
   class__class((const class__class &) *nd),
   parentnd(NULL),
   children(NULL),
   basic_status(bstatus)
{ 
   stringtable.add_string(name->get_string());          // Add class name to string table
}


//******************************************************************
//
//   Fill in the following methods to produce code for the
//   appropriate expression.  You may add or remove parameters
//   as you wish, but if you do, remember to change the parameters
//   of the declarations in `cool-tree.h'  Sample code for
//   constant integers, strings, and booleans are provided.
//
//*****************************************************************
void method_class::code(ostream &s) {
  emit_method_ref(env.get_cur_class()->get_name(), name, s);
  s << LABEL;

  // allocate stack frame
  emit_addiu(SP, SP, -12, s);
  // save old $fp, self and $ra values
  emit_store(FP, 3, SP, s);
  emit_store(SELF, 2, SP, s);
  emit_store(RA, 1, SP, s);
  // set fp to point to old $ra
  emit_addiu(FP, SP, 4, s);
  // move acc to self
  emit_move(SELF, ACC, s);

  env.set_cur_method(this);

  expr->code(s);

  // restore $fp, self and $ra
  emit_load(FP, 3, SP, s);
  emit_load(SELF, 2, SP, s);
  emit_load(RA, 1, SP, s);

  //remember that before we enter the method there are 
  //already env.get_cur_method_formals().size() pointers 
  //pushed upon the stack
  emit_addiu(SP,SP,12+env.get_cur_method_formals().size()*4,s);
  emit_return(s);
}

void assign_class::code(ostream &s) {
  expr->code(s);
  if(cgen_debug) {
    emit_push(ACC,s);
    emit_jal("IO.out_int",s);
  }
  int pos, offset;

  pos = env.find_symbol_on_stack(name);
  //dbgStream<<env.local_var_stack[0]<<env.local_var_stack[1]<<env.local_var_stack[2]<<endl;
  if (pos != -1)
  {
    dbgStream<<name<<" is on stack pos "<<pos<<endl;
    offset = pos + 1;
    emit_store(ACC, offset, SP, s);

    if (cgen_Memmgr == GC_GENGC)
    {
      emit_addiu(A1, SP, 4 * offset, s);
      emit_gc_assign(s);
    }
    return;
  }

  pos = env.find_formal_symbol(name);
  if (pos != -1)
  {
    offset = 2 + pos;
    emit_store(ACC, offset, FP, s);

    if (cgen_Memmgr == GC_GENGC)
    {
      emit_addiu(A1, FP, 4 * offset, s);
      emit_gc_assign(s);
    }
    return;
  }

  pos = env.find_class_attr_symbol(name);
  if (pos != -1)
  {
    dbgStream<<name<<" is in class slot "<<pos<<endl;
    offset = DEFAULT_OBJFIELDS + pos;
  if(cgen_debug) {
    emit_push(ACC,s);
    emit_jal("IO.out_int",s);
  }
    emit_store(ACC, offset, SELF, s);

    if (cgen_Memmgr == GC_GENGC)
    {
      emit_addiu(A1, SELF, 4 * offset, s);
      emit_gc_assign(s);
    }
    return;
  }
}

void static_dispatch_class::code(ostream &s) {
  int num_params=0;
  for (int i = actual->first(); actual->more(i); i = actual->next(i))
  {
    actual->nth(i)->code(s);
    push_local_var_on_stack(No_type,ACC,s);
    num_params++;
  }
  dbgStream<<"num_param="<<num_params<<endl;
  // $a0 = expr_obj
  expr->code(s);
  int legal_dispatch_label=alloc_label();

  emit_bne(ACC,ZERO,legal_dispatch_label,s);
  
  //Here we handle dispatch on void
  emit_partial_load_address(ACC, s);
  stringtable.lookup_string(env.get_cur_class()->get_filename()->get_string())->code_ref(s);
  s << endl;
  emit_load_imm(T1, get_line_number(), s);
  emit_jal("_dispatch_abort", s);

  emit_label_def(legal_dispatch_label,s);
  dbgStream<<ct<<endl;
  CgenNodeP cls= ct->class_name_map[this->type_name];
  int cls_tag=cls->get_tag();
  int pos=cls->find_method_id(name);

  s<<LA<<T1<<" "<<cls->get_name()<<DISPTAB_SUFFIX<<endl;

  dbgStream<<"In static_dispatch "<<name<<"@"<<type_name<<" Id="<<pos<<endl;
  emit_load(T1, pos, T1, s);
  emit_jalr(T1, s);
  for (int i = 0; i < num_params; i++)
  {
    // this simply removes the symbols from the vector
    // the callee is responsible for actually increasing the $sp
    env.pop_stack();
  }
}

void dispatch_class::code(ostream &s) {
  dbgStream<<"In dispatch_class expr->type="<<expr->type<<" name= "<<this->name<<endl;
  int num_params=0;
  for (int i = actual->first(); actual->more(i); i = actual->next(i))
  {
    actual->nth(i)->code(s);
    push_local_var_on_stack(No_type,ACC,s);
    num_params++;
  }
  dbgStream<<"num_param="<<num_params<<endl;
  // $a0 = expr_obj
  expr->code(s);
  int legal_dispatch_label=alloc_label();

  emit_bne(ACC,ZERO,legal_dispatch_label,s);
  
  //Here we handle dispatch on void
  emit_partial_load_address(ACC, s);
  stringtable.lookup_string(env.get_cur_class()->get_filename()->get_string())->code_ref(s);
  s << endl;
  emit_load_imm(T1, get_line_number(), s);
  emit_jal("_dispatch_abort", s);

  emit_label_def(legal_dispatch_label,s);
  emit_load(T1,2,ACC,s);
  dbgStream<<this->type<<expr->get_type()<<endl;
  CgenNodeP cls= expr->get_type() == SELF_TYPE? env.get_cur_class(): ct->class_name_map[expr->get_type()];
  int pos=cls->find_method_id(name);
  dbgStream<<"In dispatch "<<name<<" Id="<<pos<<endl;
  emit_load(T1, pos, T1, s);
  emit_jalr(T1, s);
  for (int i = 0; i < num_params; i++)
  {
    // this simply removes the symbols from the vector
    // the callee is responsible for actually increasing the $sp
    env.pop_stack();
  }
}

void cond_class::code(ostream &s) {
  this->pred->code(s);
  emit_fetch_int(T1,ACC,s);

  int false_label=alloc_label();
  int end_label=alloc_label();

  emit_beqz(T1,false_label,s);
  this->then_exp->code(s);
  emit_branch(end_label,s);

  emit_label_def(false_label,s);
  this->else_exp->code(s);
  emit_label_def(end_label,s);
}

void loop_class::code(ostream &s) {
  int loop_label=alloc_label();
  int end_label=alloc_label();
  emit_label_def(loop_label,s);

  this->pred->code(s);
  emit_fetch_int(T1,ACC,s);
  emit_beqz(T1,end_label,s);
  body->code(s);
  emit_branch(loop_label,s);
  emit_label_def(end_label,s);
  emit_move(ACC,ZERO,s);//loop always returns false
}

/**
 * typecase code generation, we choose the O(n^2) BF algorithm,
 * go up the parent chain to the root while checking every branch
 * at each level of the inheritance tree.
 * 
*/
void typcase_class::code(ostream &s) {
  this->expr->code(s);
  emit_push(ACC,s);
  // first we push the expr-object to the stack without giving it
  // a name, since its name depends on the specific branch the 
  // program finally goes into.
  
  int valid_object_typecase_label=alloc_label();

  //if ACC==ZERO, a cast_abort2 is called.
  emit_bne(ACC,ZERO,valid_object_typecase_label,s);

  emit_partial_load_address(ACC, s);
  stringtable.lookup_string(env.get_cur_class()->get_filename()->get_string())->code_ref(s);
  s << endl;
  emit_load_imm(T1, get_line_number(), s);
  emit_jal("_case_abort2", s);

  emit_label_def(valid_object_typecase_label,s);
  
  //beneath the label we enter the procedure of checking cases.

  int begin_label=alloc_label(),end_label=alloc_label(),tag_valid_label=alloc_label();

  // $t1 = expr_obj.tag
  emit_load(T1, TAG_OFFSET, ACC, s);

  //here we generate a loop to check each branch
  
}

void block_class::code(ostream &s)
{
  for (int i = body->first(); body->more(i); i = body->next(i))
  {
    body->nth(i)->code(s);
  }
}

void let_class::code(ostream &s) {
  dbgStream<<"Coding let_class "<<this->identifier<<endl;
  this->init->code(s);
  s<<"#this->init->code\n";
  if(init->is_void()) {
    if (type_decl == Str) {
      emit_load_string(ACC, stringtable.lookup_string(""), s);
    } else if (type_decl == Int) {
      emit_load_int(ACC, inttable.lookup_string("0"), s);
    } else if (type_decl == Bool) {
      emit_load_bool(ACC, falsebool, s);
    }
  }
  //dbgStream<<env.local_var_stack[0]<<env.local_var_stack.size();
  push_local_var_on_stack(identifier,ACC,s);
  dbgStream<<"pushed into the stack"<<endl;
  s<<"#pushed onto stack\n";
  this->body->code(s);
  //dbgStream<<env.local_var_stack[0]<<env.local_var_stack[1]<<env.local_var_stack[2]<<env.local_var_stack.size();
  s<<"#going to pop\n";
  pop_discard_local_var_on_stack(s);
  dbgStream<<"end Coding let_class "<<identifier<<endl;
}

void plus_class::code(ostream &s) {
  e1->code(s);
  push_local_var_on_stack(No_type,ACC,s);

  e2->code(s);
  emit_jal("Object.copy",s);
  //e1 and e2 may in the .data section, thus not writable, to 
  //get a r/w Int object we either copy the prototype or e1/2
  //here we choose to copy e2, the copy is now in a0

  pop_local_var_on_stack(T1,s);
  //load e1 into t1

  emit_fetch_int(T1,T1,s);
  //load the integer in e1 into t1
  emit_fetch_int(T2,ACC,s);
  //load the integer in new e2 into t2
  emit_add(T3,T1,T2,s);
  emit_store_int(T3,ACC,s);

  if(cgen_debug) {
    //TEST CODE, call IO.out_int to show the value
    emit_push(ACC,s);
    emit_jal("IO.out_int",s);    
  }

}

void sub_class::code(ostream &s) {
  e1->code(s);
  push_local_var_on_stack(No_type,ACC,s);

  e2->code(s);
  emit_jal("Object.copy",s);
  //e1 and e2 may in the .data section, thus not writable, to 
  //get a r/w Int object we either copy the prototype or e1/2
  //here we choose to copy e2, the copy is now in a0

  pop_local_var_on_stack(T1,s);
  //load e1 into t1

  emit_fetch_int(T1,T1,s);
  //load the integer in e1 into t1
  emit_fetch_int(T2,ACC,s);
  //load the integer in new e2 into t2
  emit_sub(T3,T1,T2,s);
  emit_store_int(T3,ACC,s);

  if(cgen_debug) {
    //TEST CODE, call IO.out_int to show the value
    emit_push(ACC,s);
    emit_jal("IO.out_int",s);    
  }
}

void mul_class::code(ostream &s) {
  e1->code(s);
  push_local_var_on_stack(No_type,ACC,s);

  e2->code(s);
  emit_jal("Object.copy",s);
  //e1 and e2 may in the .data section, thus not writable, to 
  //get a r/w Int object we either copy the prototype or e1/2
  //here we choose to copy e2, the copy is now in a0

  pop_local_var_on_stack(T1,s);
  //load e1 into t1

  emit_fetch_int(T1,T1,s);
  //load the integer in e1 into t1
  emit_fetch_int(T2,ACC,s);
  //load the integer in new e2 into t2
  emit_mul(T3,T1,T2,s);
  emit_store_int(T3,ACC,s);

  if(cgen_debug) {
    //TEST CODE, call IO.out_int to show the value
    emit_push(ACC,s);
    emit_jal("IO.out_int",s);    
  }
}

void divide_class::code(ostream &s) {
  e1->code(s);
  push_local_var_on_stack(No_type,ACC,s);

  e2->code(s);
  emit_jal("Object.copy",s);
  //e1 and e2 may in the .data section, thus not writable, to 
  //get a r/w Int object we either copy the prototype or e1/2
  //here we choose to copy e2, the copy is now in a0

  pop_local_var_on_stack(T1,s);
  //load e1 into t1

  emit_fetch_int(T1,T1,s);
  //load the integer in e1 into t1
  emit_fetch_int(T2,ACC,s);
  //load the integer in new e2 into t2
  emit_div(T3,T1,T2,s);
  emit_store_int(T3,ACC,s);

  if(cgen_debug) {
    //TEST CODE, call IO.out_int to show the value
    emit_push(ACC,s);
    emit_jal("IO.out_int",s);    
  }
}

void neg_class::code(ostream &s) {
  this->e1->code(s);
  emit_jal("Object.copy",s);
  emit_fetch_int(T1,ACC,s);
  emit_neg(T1,T1,s);
  emit_store_int(T1,ACC,s);

  if(cgen_debug) {
    //TEST CODE, call IO.out_int to show the value
    emit_push(ACC,s);
    emit_jal("IO.out_int",s);    
  }
}

/* lt_class and leq_class specify integer comparison*/
void lt_class::code(ostream &s) {
  this->e1->code(s);
  push_local_var_on_stack(No_type,ACC,s);

  this->e2->code(s);// e2 now in ACC
  
  pop_local_var_on_stack(T1,s);// e1 now in T1

  emit_fetch_int(T2,ACC,s);
  emit_fetch_int(T1,T1,s);

  emit_load_bool(ACC,truebool,s);

  int skip_label=alloc_label();

  emit_blt(T1,T2,skip_label,s);
  emit_load_bool(ACC,falsebool,s);
  emit_label_def(skip_label,s);
}

/**
 *  The comparison = is a special case. If either <expr1> or <expr2> 
 * has static type Int, Bool, or String, then the other must have the 
 * same static type. Any other types, including SELF TYPE, may be freely 
 * compared. On non-basic objects, equality simply checks for pointer 
 * equality (i.e., whether the memory addresses of the objects are the 
 * same). Equality is defined for void.
 *          - from the Cool Reference Manual.
 * 
 * equality test: # ops in $t1 $t2
 *                # true in A0, false in A1
 *                # assume $t1, $t2 are not equal
*/
void eq_class::code(ostream &s) {
  this->e1->code(s);
  push_local_var_on_stack(No_type,ACC,s);

  this->e2->code(s);// e2 now in ACC
  
  pop_local_var_on_stack(T1,s);// e1 now in T1
  emit_move(T2,ACC,s); // e2 now in T2

  if (e1->type == Int || e1->type == Str || e1->type == Bool) {
    int object_eq_label=alloc_label();//in case T1 and T2 represents the same Int/Bool/String
    int end_label=alloc_label();

    emit_beq(T1,T2,object_eq_label,s);
    
    emit_load_bool(ACC, truebool, s);
    emit_load_bool(A1, falsebool, s);
    emit_jal("equality_test", s);
    emit_branch(end_label,s);

    emit_label_def(object_eq_label,s);
    emit_load_bool(ACC,truebool,s);
    emit_label_def(end_label,s);
    return;
  }
  int skip_label=alloc_label();
  emit_load_bool(ACC, truebool, s);
  emit_beq(T1, T2, skip_label, s);
  emit_load_bool(ACC, falsebool, s);
  emit_label_def(skip_label, s);
}

void leq_class::code(ostream &s) {
  this->e1->code(s);
  push_local_var_on_stack(No_type,ACC,s);

  this->e2->code(s);// e2 now in ACC
  
  pop_local_var_on_stack(T1,s);// e1 now in T1

  emit_fetch_int(T2,ACC,s);
  emit_fetch_int(T1,T1,s);

  emit_load_bool(ACC,truebool,s);

  int skip_label=alloc_label();

  emit_bleq(T1,T2,skip_label,s);
  emit_load_bool(ACC,falsebool,s);
  emit_label_def(skip_label,s);
}

/* not expressions */
void comp_class::code(ostream &s) {
  this->e1->code(s);
  emit_fetch_int(T1,ACC,s);// bool values in Bool object is stored as a word(integer) actually.
  int false_to_true_label=alloc_label();

  emit_load_bool(ACC,truebool,s);
  emit_beqz(T1,false_to_true_label,s);
  emit_load_bool(ACC,falsebool,s);

  emit_label_def(false_to_true_label,s);
}

void int_const_class::code(ostream& s)  
{
  //
  // Need to be sure we have an IntEntry *, not an arbitrary Symbol
  //
  emit_load_int(ACC,inttable.lookup_string(token->get_string()),s);
}

void string_const_class::code(ostream& s)
{
  emit_load_string(ACC,stringtable.lookup_string(token->get_string()),s);
}

void bool_const_class::code(ostream& s)
{
  emit_load_bool(ACC, BoolConst(val), s);
}

void new__class::code(ostream &s) {
  if(this->type_name!=SELF_TYPE ) {
    s << LA << ACC << " " << this->type_name<<PROTOBJ_SUFFIX << endl; 
    //emit_load_address(ACC,this->type_name->get_string())
    emit_jal("Object.copy",s);
    s << JAL << type_name<<CLASSINIT_SUFFIX << endl;
  } else {
    emit_load_address(T1,CLASSOBJTAB,s);
    emit_load(T2,0,SELF,s);
  if(cgen_debug) {
    emit_load_imm("$v0",1,s);
    emit_move(ACC,T2,s);
    s<<"\tsyscall"<<endl;
  }

    //emit_addiu(T2,T2,-1,s);
    emit_sll(T2,T2,3,s);
    emit_add(T1,T1,T2,s);

    //emit_push(T1,s);
    push_local_var_on_stack(No_type,T1,s);

    emit_load(ACC,0,T1,s);

  //int debug_label=alloc_label();

    emit_jal("Object.copy",s);

    // pop old pointer from the stack to $t1
    pop_local_var_on_stack(T1,s);
    //emit_addiu(SP, SP, 4, s);
    //emit_load(T1, 0, SP, s);

    // $t1 += 1 so it now points to SELF_TYPE_CLASS_init
    emit_load(T1, 1, T1, s);
    emit_jalr(T1, s);
  }
}

void isvoid_class::code(ostream &s) {
    e1->code(s);
    emit_move(T1, ACC, s);

    emit_load_bool(ACC, truebool, s);

    int skip_label=alloc_label();
    emit_beq(T1, ZERO, skip_label, s);
    emit_load_bool(ACC, falsebool, s);

    emit_label_def(skip_label, s);
}

void no_expr_class::code(ostream &s) {
  emit_move(ACC,ZERO,s);
}

void object_class::code(ostream &s) {
  int pos;
  if( (pos=env.find_symbol_on_stack(this->name) ) !=-1) {
    emit_load(ACC,pos+1,SP,s);
    return;
  } 
  if((pos=env.find_formal_symbol(this->name))!=-1) {
    emit_load(ACC,2+pos,FP,s);
    return;
  }
  if((pos=env.find_class_attr_symbol(this->name))!=-1) {
    emit_load(ACC,DEFAULT_OBJFIELDS+pos,SELF,s);
    return;
  }
  emit_move(ACC,SELF,s);
}


